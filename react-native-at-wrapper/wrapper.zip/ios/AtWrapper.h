#import <React/RCTBridgeModule.h>

@interface AtWrapper : NSObject <RCTBridgeModule>

@end
